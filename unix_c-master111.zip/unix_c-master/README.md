# unix_c
Linux环境Ｃ代码，来自书&lt;Unix/Linux 编程实践教程>
